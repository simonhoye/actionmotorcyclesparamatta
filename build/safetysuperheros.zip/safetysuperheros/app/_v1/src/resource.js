var s_HelloWorld = "res/HelloWorld.png";
var s_CloseNormal = "res/CloseNormal.png";
var s_CloseSelected = "res/CloseSelected.png";
var s_Font = "res/font.fnt";
var s_BackgroundMusic = "res/background.mp3";
var s_Saucepan = "res/game-test.png";

var g_resources = [
    //image
    {src:s_HelloWorld},
    {src:s_CloseNormal},
    {src:s_CloseSelected},
    {src:s_Saucepan},

    //plist

    //fnt
    {src:s_Font},
    //tmx

    //bgm
    {src:s_BackgroundMusic}

    //effect
];